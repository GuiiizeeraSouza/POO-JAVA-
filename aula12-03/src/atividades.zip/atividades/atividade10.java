package atividades;

public class atividade10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

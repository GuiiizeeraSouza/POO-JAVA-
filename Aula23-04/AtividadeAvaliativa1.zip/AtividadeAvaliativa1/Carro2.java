public class Carro2 {
    private String placa;
    private int numChassi;

    public Carro2(String placa, int numChassi){
        this.numChassi = numChassi;
        this.placa = placa;
    }

    public void acelerar(){

    }

    public boolean frear() {

    }
    
}
